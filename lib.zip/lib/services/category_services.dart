import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:rentit24/model/category_model.dart';
import 'package:rentit24/services/api_services.dart';

class CategoryService {
  final ApiService _apiService = ApiService();

  Future<List<CategoryModel>> getCategories() async {
    try {
      final Response<dynamic> response =
          await _apiService.dio.get(
        '/category/all',
        options: Options(
          // Allows us to read 401, 403, 404 responses instead of Dio
          // immediately hiding them inside DioException.
          validateStatus: (status) => status != null,
        ),
      );

      final int statusCode = response.statusCode ?? 0;

      debugPrint('================ CATEGORY API ================');
      debugPrint('Status code: $statusCode');
      debugPrint('Response type: ${response.data.runtimeType}');
      debugPrint('Response body: ${response.data}');
      debugPrint('==============================================');

      if (statusCode < 200 || statusCode >= 300) {
        throw Exception(
          'Category API failed: HTTP $statusCode\n${response.data}',
        );
      }

      final dynamic categoryData = _extractCategoryData(
        response.data,
      );

      if (categoryData is! List) {
        throw FormatException(
          'Expected category list but received '
          '${categoryData.runtimeType}: $categoryData',
        );
      }

      final List<CategoryModel> categories = [];

      for (final dynamic item in categoryData) {
        if (item is Map) {
          final Map<String, dynamic> json =
              Map<String, dynamic>.from(item);

          final CategoryModel category =
              CategoryModel.fromJson(json);

          if (category.name.trim().isNotEmpty) {
            categories.add(category);
          }
        }
      }

      categories.sort(
        (first, second) =>
            first.sortOrder.compareTo(second.sortOrder),
      );

      debugPrint(
        'Successfully parsed ${categories.length} categories',
      );

      for (final category in categories) {
        debugPrint(
          'Category => '
          'id: ${category.id}, '
          'name: ${category.name}, '
          'type: ${category.type}, '
          'active: ${category.isActive}',
        );
      }

      return categories;
} on DioException catch (error, stackTrace) {
      final int? statusCode = error.response?.statusCode;
      final dynamic responseBody = error.response?.data;

      // error.message is frequently null for connection-level failures
      // (CORS blocks on web, DNS failure, TLS errors, timeouts with no
      // underlying exception attached). Fall back to error.error and
      // finally error.type so we never print the bare string "null".
      final String underlying =
          error.message?.toString() ??
          error.error?.toString() ??
          'DioException type: ${error.type.name}';

      debugPrint('Category network error type: ${error.type}');
      debugPrint('Category network error message: $underlying');
      debugPrint('Category error status: $statusCode');
      debugPrint('Category error body: $responseBody');
      debugPrintStack(stackTrace: stackTrace);

      final String detail =
          responseBody != null && responseBody.toString().isNotEmpty
              ? responseBody.toString()
              : underlying;

      throw Exception(
        'Network error'
        '${statusCode != null ? ' ($statusCode)' : ''}: $detail',
      );
    } catch (error, stackTrace) {
      debugPrint('Category service error: $error');
      debugPrintStack(stackTrace: stackTrace);

      rethrow;
    }
  }

  dynamic _extractCategoryData(dynamic responseData) {
    dynamic data = responseData;

    // Complete response is a JSON string.
    if (data is String) {
      data = _decodeString(data);
    }

    // API wrapper:
    // {
    //   "res": [...],
    //   "rescode": "...",
    //   "restype": "..."
    // }
    if (data is Map) {
      data =
          data['res'] ??
          data['data'] ??
          data['categories'] ??
          data['result'];
    }

    // "res" itself may be a JSON string.
    if (data is String) {
      data = _decodeString(data);
    }

    // The list may be nested one level deeper.
    if (data is Map) {
      data =
          data['content'] ??
          data['categories'] ??
          data['data'] ??
          data['result'] ??
          data['res'];
    }

    return data;
  }

  dynamic _decodeString(String rawData) {
    final String cleaned = rawData.trim();

    if (cleaned.isEmpty) {
      return <dynamic>[];
    }

    try {
      return jsonDecode(cleaned);
    } catch (_) {
      return _parseLegacyResponse(cleaned);
    }
  }

  List<Map<String, dynamic>> _parseLegacyResponse(
    String data,
  ) {
    final List<Map<String, dynamic>> categories = [];

    // Supports:
    // {id=1, name=Vehicles, ...}
    // {id: 1, name: Vehicles, ...}
    // Category(id=1, name=Vehicles, ...)
    final RegExp itemPattern = RegExp(
      r'(?:\{|\()([^{}()]*(?:id|name)\s*[:=][^{}()]*)(?:\}|\))',
      caseSensitive: false,
    );

    final Iterable<RegExpMatch> matches =
        itemPattern.allMatches(data);

    for (final RegExpMatch match in matches) {
      final String item = match.group(1) ?? '';

      String? getValue(List<String> keys) {
        for (final String key in keys) {
          final RegExpMatch? valueMatch = RegExp(
            '(?:^|,)\\s*'
            '${RegExp.escape(key)}'
            '\\s*[:=]\\s*([^,}\\)]*)',
            caseSensitive: false,
          ).firstMatch(item);

          final String? value =
              valueMatch?.group(1)?.trim();

          if (value != null && value.isNotEmpty) {
            return value;
          }
        }

        return null;
      }

      final String name =
          getValue([
            'name',
            'category_name',
            'categoryName',
          ]) ??
          '';

      if (name.isEmpty) {
        continue;
      }

      categories.add({
        'id': getValue([
          'id',
          'category_id',
          'categoryId',
        ]),
        'name': name,
        'type': getValue([
          'type',
          'category_type',
          'categoryType',
        ]),
        'sort_order': getValue([
          'sort_order',
          'sortOrder',
        ]),
        'is_active': getValue([
          'is_active',
          'isActive',
          'active',
        ]),
      });
    }

    if (categories.isEmpty) {
      throw FormatException(
        'Unsupported category response: $data',
      );
    }

    return categories;
  }
}