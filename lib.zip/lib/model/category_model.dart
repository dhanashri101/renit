class CategoryModel {
  final int id;
  final String name;
  final String type;
  final int sortOrder;
  final bool isActive;

  const CategoryModel({
    required this.id,
    required this.name,
    required this.type,
    required this.sortOrder,
    required this.isActive,
  });
  factory CategoryModel.fromJson(
    Map<String, dynamic> json,
  ) {
    return CategoryModel(
      id: _convertToInt(
        json['id'] ??
            json['category_id'] ??
            json['categoryId'],
      ),
      name: (
        json['name'] ??
        json['category_name'] ??
        json['categoryName'] ??
        ''
      ).toString().trim(),
      type: (
        json['type'] ??
        json['category_type'] ??
        json['categoryType'] ??
        ''
      ).toString().trim(),
      sortOrder: _convertToInt(
        json['sort_order'] ??
            json['sortOrder'],
      ),
      isActive: _convertToBool(
        json['is_active'] ??
            json['isActive'] ??
            json['active'],
      ),
    );
  }
 
  static int _convertToInt(dynamic value) {
    if (value is int) {
      return value;
    }

    if (value is double) {
      return value.toInt();
    }

    return int.tryParse(
          value?.toString().trim() ?? '',
        ) ??
        0;
  }

  static bool _convertToBool(dynamic value) {
    if (value is bool) {
      return value;
    }

    if (value is int) {
      return value == 1;
    }

    final String converted =
        value?.toString().trim().toLowerCase() ?? '';

    return converted == 'true' ||
        converted == '1' ||
        converted == 'yes' ||
        converted == 'active' ||
        converted == 'y';
  }
}